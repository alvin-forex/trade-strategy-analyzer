CurrencyPower v3 — Audit Package (2026-10-20)
=============================================
MT5/  CurrencyPower_v3.mq5   v3.10 源碼
      CurrencyPower_v3.ex5   編譯成品 (2026-10-20 10:51, 0 errors 0 warnings)
MT4/  CurrencyPower_v3_MQ4.mq4  v3.07-MQ4 源碼
      CurrencyPower_v3_MQ4.ex4   編譯成品 (如附)
docs/ CurrencyPower_v3_WhitePaper_v310.pdf  白皮書 (9 頁, audit 版)

版本差異提要（詳見白皮書 §6/§8）:
- MT5 v3.10: TOP PAIRS + expand + cached redraw + Alert_On(70/30) + scoped OnDeinit
- MT4 v3.07: TOP PAIRS + expand + cached redraw + scoped OnDeinit; Alert_On 尚未實作 (A1)
- 已知缺陷: A2 半權重 / A3 早期空白 / A4 CPU 全量重算 / B7 視覺小瑕疵
